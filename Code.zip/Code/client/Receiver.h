#ifndef RECEIVER_H_
#define RECEIVER_H_
#include <cstdint>
#include <string>

using namespace std;

class recApp
{
public:
	recApp(string bin);

};

class Receiver {
};

#endif /* RECEIVER_H_ */
