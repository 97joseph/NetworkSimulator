#ifndef TRANSMITTER_H_
#define TRANSMITTER_H_
#include <cstdint>
#include <string>

using namespace std;

class transApp
{
public:
	transApp(string filename);

};




class transmitter {
public:
	transmitter();
	virtual ~transmitter();
};

#endif /* TRANSMITTER_H_ */
